# ActiveJob::Base.queue_adapter = :inline
ActiveJob::Base.queue_adapter = :sucker_punch
